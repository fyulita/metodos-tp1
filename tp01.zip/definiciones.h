#ifndef SOLUCION_DEFINICIONES_H
#define SOLUCION_DEFINICIONES_H

#include <vector>

using namespace std;


using matrix =vector<vector<double>>;

#endif //SOLUCION_DEFINICIONES_H
